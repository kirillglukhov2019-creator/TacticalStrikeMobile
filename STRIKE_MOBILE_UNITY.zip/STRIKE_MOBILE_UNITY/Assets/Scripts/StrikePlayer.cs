using UnityEngine;
using UnityEngine.EventSystems;

[RequireComponent(typeof(CharacterController))]
public class StrikePlayer : MonoBehaviour
{
    public float moveSpeed = 5.2f;
    public float lookSensitivity = 2.1f;
    public float gravity = -20f;
    public Transform cameraPivot;
    CharacterController cc;
    float pitch;
    Vector3 velocity;
    Vector2 moveStick;
    int lookFinger = -1;
    Vector2 lastLook;
    bool mobileLook;

    void Start()
    {
        cc = GetComponent<CharacterController>();
        if (cameraPivot == null && Camera.main) cameraPivot = Camera.main.transform;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Update()
    {
        if (StrikeGame.I != null && StrikeGame.I.dead) return;
        Vector2 move = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        if (moveStick.sqrMagnitude > .01f) move = moveStick;
        move = Vector2.ClampMagnitude(move, 1);
        Vector3 wish = transform.right * move.x + transform.forward * move.y;
        if (cc.isGrounded && velocity.y < 0) velocity.y = -2;
        velocity.y += gravity * Time.deltaTime;
        cc.Move((wish * moveSpeed + velocity) * Time.deltaTime);

        if (Input.GetMouseButton(1) || !Application.isMobilePlatform)
        {
            float mx = Input.GetAxis("Mouse X") * lookSensitivity;
            float my = Input.GetAxis("Mouse Y") * lookSensitivity;
            Look(mx, my);
        }
        HandleTouch();
    }

    void Look(float x, float y)
    {
        transform.Rotate(0, x, 0);
        pitch = Mathf.Clamp(pitch - y, -82, 82);
        if (cameraPivot) cameraPivot.localRotation = Quaternion.Euler(pitch, 0, 0);
    }

    void HandleTouch()
    {
        if (!Input.touchSupported) return;
        foreach (Touch t in Input.touches)
        {
            if (t.phase == TouchPhase.Began)
            {
                if (t.position.x > Screen.width * .42f) { lookFinger = t.fingerId; lastLook = t.position; mobileLook = true; }
            }
            else if (t.fingerId == lookFinger && mobileLook)
            {
                if (t.phase == TouchPhase.Moved)
                {
                    Vector2 delta = t.position - lastLook;
                    Look(delta.x * .12f, delta.y * .12f);
                    lastLook = t.position;
                }
                if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) { lookFinger = -1; mobileLook = false; }
            }
        }
    }

    public void SetMoveStick(Vector2 value) { moveStick = Vector2.ClampMagnitude(value, 1); }
}
