using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class StrikeMobileUI : MonoBehaviour
{
    StrikeGame game;
    void Start() { game = StrikeGame.I; }
    void OnGUI()
    {
        if (game == null) game = StrikeGame.I;
        if (game == null) return;
        GUI.skin.label.fontSize = Mathf.Max(14, Screen.height / 48);
        GUI.skin.button.fontSize = Mathf.Max(14, Screen.height / 48);
        float scale = Mathf.Clamp(Screen.height / 720f, .8f, 1.5f);
        if (Application.isMobilePlatform)
        {
            float s = 115 * scale;
            GUI.Box(new Rect(22, Screen.height - s - 25, s, s), "ДВИЖЕНИЕ");
            if (GUI.RepeatButton(new Rect(22+s*.32f, Screen.height-s-22, s*.36f, s*.34f), "▲")) Move(0,1);
            else if (GUI.RepeatButton(new Rect(22+s*.32f, Screen.height-s*.32f, s*.36f, s*.30f), "▼")) Move(0,-1);
            else if (GUI.RepeatButton(new Rect(22, Screen.height-s*.66f, s*.32f, s*.34f), "◀")) Move(-1,0);
            else if (GUI.RepeatButton(new Rect(22+s*.68f, Screen.height-s*.66f, s*.32f, s*.34f), "▶")) Move(1,0);
            else Move(0,0);
            if (GUI.RepeatButton(new Rect(Screen.width-125*scale, Screen.height-150*scale, 105*scale, 60*scale), "ОГОНЬ")) game.SendMessage("Shoot", SendMessageOptions.DontRequireReceiver);
            if (GUI.Button(new Rect(Screen.width-125*scale, Screen.height-80*scale, 105*scale, 48*scale), "RELOAD")) game.Reload();
            if (GUI.Button(new Rect(Screen.width-245*scale, 20, 105*scale, 48*scale), "МАГАЗИН")) game.shopOpen = !game.shopOpen;
        }
        if (game.shopOpen)
        {
            float w = Mathf.Min(360, Screen.width-30), h = 250;
            Rect panel = new Rect((Screen.width-w)/2, (Screen.height-h)/2, w, h);
            GUI.Box(panel, "МАГАЗИН ОРУЖИЯ  |  МОНЕТЫ: " + game.coins.ToString("N0"));
            if (GUI.Button(new Rect(panel.x+15,panel.y+45,w-30,42),"AK-47  —  выбрать [1]")) game.Buy("AK-47");
            if (GUI.Button(new Rect(panel.x+15,panel.y+95,w-30,42),"M4A4  —  выбрать [2]")) game.Buy("M4A4");
            if (GUI.Button(new Rect(panel.x+15,panel.y+145,w-30,42),"Glock  —  выбрать [3]")) game.Buy("Glock");
            if (GUI.Button(new Rect(panel.x+15,panel.y+195,w-30,38),"ЗАКРЫТЬ")) game.shopOpen = false;
        }
    }
    void Move(float x, float y) { var p = FindObjectOfType<StrikePlayer>(); if (p) p.SetMoveStick(new Vector2(x,y)); }
}
