using UnityEngine;

public class StrikeBot : MonoBehaviour
{
    public float maxHealth = 100;
    public float moveSpeed = 1.5f;
    public bool IsDead { get; private set; }
    float hp;
    float attackTimer;
    Transform player;
    Renderer[] renderers;
    Color originalColor;

    void Start()
    {
        hp = maxHealth;
        if (StrikeGame.I != null) { player = StrikeGame.I.player; StrikeGame.I.RegisterBot(this); }
        renderers = GetComponentsInChildren<Renderer>();
        if (renderers.Length > 0) originalColor = renderers[0].material.color;
    }

    void Update()
    {
        if (IsDead || player == null || (StrikeGame.I != null && StrikeGame.I.dead)) return;
        Vector3 delta = player.position - transform.position;
        delta.y = 0;
        float dist = delta.magnitude;
        if (dist > 4.5f) {
            transform.position += delta.normalized * moveSpeed * Time.deltaTime;
            if (delta.sqrMagnitude > .01f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(delta), Time.deltaTime * 4);
        } else {
            attackTimer -= Time.deltaTime;
            if (attackTimer <= 0) { attackTimer = 1.2f; StrikeGame.I.DamagePlayer(8); }
        }
    }

    public void Hit(float damage)
    {
        if (IsDead) return;
        hp -= damage;
        if (hp <= 0) {
            IsDead = true;
            if (StrikeGame.I != null) { StrikeGame.I.kills++; StrikeGame.I.coins += 300; StrikeGame.I.Say("+300 монет"); }
            Destroy(gameObject, .15f);
        } else {
            foreach (Renderer r in renderers) if (r) r.material.color = Color.red;
            CancelInvoke(nameof(ResetColor)); Invoke(nameof(ResetColor), .12f);
        }
    }
    void ResetColor() { foreach (Renderer r in renderers) if (r) r.material.color = originalColor; }
}
