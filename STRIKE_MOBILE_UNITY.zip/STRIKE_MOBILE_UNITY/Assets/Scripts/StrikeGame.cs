using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;

public class StrikeGame : MonoBehaviour
{
    public static StrikeGame I;
    public int coins = 1000000000;
    public int kills;
    public int ammo = 30;
    public int magSize = 30;
    public int reserve = 90;
    public int health = 100;
    public string weapon = "M4A4";
    public float damage = 34f;
    public float fireDelay = 0.11f;
    public float reloadTime = 1.6f;
    public bool reloading;
    public bool shopOpen;
    public bool dead;
    public Transform player;
    public Camera cam;
    public Text hud;
    public Text notice;
    public float noticeTimer;
    float nextShot;
    float reloadTimer;
    readonly List<StrikeBot> bots = new List<StrikeBot>();

    void Awake() { I = this; }
    public void RegisterBot(StrikeBot bot) { if (!bots.Contains(bot)) bots.Add(bot); }

    void Update()
    {
        if (noticeTimer > 0) { noticeTimer -= Time.deltaTime; if (notice) notice.enabled = noticeTimer > 0; }
        if (reloading) {
            reloadTimer -= Time.deltaTime;
            if (reloadTimer <= 0) { int n = Mathf.Min(magSize - ammo, reserve); ammo += n; reserve -= n; reloading = false; Say("Перезарядка завершена"); }
        }
        if (Input.GetKeyDown(KeyCode.R)) Reload();
        if (Input.GetKeyDown(KeyCode.B)) shopOpen = !shopOpen;
        if (Input.GetKeyDown(KeyCode.Alpha1)) Buy("AK-47");
        if (Input.GetKeyDown(KeyCode.Alpha2)) Buy("M4A4");
        if (Input.GetKeyDown(KeyCode.Alpha3)) Buy("Glock");
        if (Input.GetMouseButton(0) && !shopOpen) Shoot();
        UpdateHud();
    }

    void Shoot()
    {
        if (Time.time < nextShot || reloading || dead) return;
        nextShot = Time.time + fireDelay;
        if (ammo <= 0) { Say("Нет патронов — нажми R"); return; }
        ammo--;
        Ray ray = cam.ScreenPointToRay(new Vector3(Screen.width * .5f, Screen.height * .5f, 0));
        if (Physics.Raycast(ray, out RaycastHit hit, 120f)) {
            StrikeBot bot = hit.collider.GetComponentInParent<StrikeBot>();
            if (bot != null) bot.Hit(damage);
        }
    }

    public void Reload()
    {
        if (!reloading && ammo < magSize && reserve > 0) {
            reloading = true; reloadTimer = reloadTime; Say("Перезарядка...");
        }
    }

    public void Buy(string name)
    {
        if (name == "AK-47") { weapon = name; damage = 42; fireDelay = .13f; magSize = 30; reloadTime = 1.8f; }
        else if (name == "M4A4") { weapon = name; damage = 34; fireDelay = .105f; magSize = 30; reloadTime = 1.6f; }
        else { weapon = "Glock"; damage = 24; fireDelay = .22f; magSize = 20; reloadTime = 1.35f; }
        ammo = magSize; reserve = Mathf.Max(reserve, 90); shopOpen = false;
        Say("Выбрано оружие: " + weapon);
    }

    public void Say(string s) { if (notice) { notice.text = s; notice.enabled = true; noticeTimer = 2f; } }

    void UpdateHud()
    {
        if (!hud) return;
        hud.text = $"{weapon}   {ammo}/{reserve}\nHP {health}     БОТЫ: {bots.FindAll(x => x != null && !x.IsDead).Count}     УБИЙСТВА: {kills}     $ {coins:N0}";
    }

    public void DamagePlayer(int d)
    {
        if (dead) return;
        health = Mathf.Max(0, health - d);
        if (health <= 0) { dead = true; Say("ВЫ УБИТЫ — нажми Enter для возрождения"); }
    }
    public void Respawn()
    {
        health = 100; dead = false;
        if (player) player.position = new Vector3(0, 1, -8);
        Say("Возрождение");
    }
    void LateUpdate() { if (dead && Input.GetKeyDown(KeyCode.Return)) Respawn(); }
}
