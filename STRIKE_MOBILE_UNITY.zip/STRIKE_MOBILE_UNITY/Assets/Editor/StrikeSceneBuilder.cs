#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class StrikeSceneBuilder
{
    [MenuItem("STRIKE MOBILE/Generate Playable Scene")]
    public static void Build()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        RenderSettings.ambientLight = new Color(.48f,.48f,.48f);
        RenderSettings.fog = true; RenderSettings.fogColor = new Color(.68f,.61f,.49f); RenderSettings.fogDensity = .008f;

        var sun = new GameObject("Sun"); var light = sun.AddComponent<Light>(); light.type = LightType.Directional; light.intensity = 1.2f; sun.transform.rotation = Quaternion.Euler(48,-32,0);

        Material sand = Mat(new Color(.58f,.46f,.31f));
        Material wall = Mat(new Color(.72f,.61f,.43f));
        Material blue = Mat(new Color(.12f,.28f,.42f));
        Material dark = Mat(new Color(.06f,.075f,.085f));
        Material red = Mat(new Color(.45f,.13f,.09f));

        Cube("Arena Floor", new Vector3(0,-.5f,0), new Vector3(50,1,50), sand);
        Cube("North Wall", new Vector3(0,2,24), new Vector3(50,4,1), wall);
        Cube("South Wall", new Vector3(0,2,-24), new Vector3(50,4,1), wall);
        Cube("East Wall", new Vector3(24,2,0), new Vector3(1,4,50), wall);
        Cube("West Wall", new Vector3(-24,2,0), new Vector3(1,4,50), wall);
        // cover and central lanes
        Cube("Mid Container A", new Vector3(-7,1,1), new Vector3(5,2,3), blue);
        Cube("Mid Container B", new Vector3(8,1,4), new Vector3(5,2,3), red);
        Cube("Long Box A", new Vector3(0,1,-10), new Vector3(7,2,3), wall);
        Cube("Long Box B", new Vector3(0,1,13), new Vector3(7,2,3), wall);
        Cube("Crate A", new Vector3(-13,1,9), new Vector3(3,2,3), wall);
        Cube("Crate B", new Vector3(13,1,-4), new Vector3(3,2,3), wall);
        Cube("Crate C", new Vector3(-13,1,-14), new Vector3(3,2,3), wall);
        Cube("Crate D", new Vector3(14,1,15), new Vector3(3,2,3), wall);

        var player = new GameObject("Player");
        player.transform.position = new Vector3(0,1,-17);
        var cc = player.AddComponent<CharacterController>(); cc.height=1.8f; cc.radius=.32f; cc.center=new Vector3(0,0,0);
        var pivot = new GameObject("Camera Pivot"); pivot.transform.SetParent(player.transform); pivot.transform.localPosition=new Vector3(0,.62f,0);
        var cameraGO = new GameObject("Main Camera"); cameraGO.tag="MainCamera"; cameraGO.transform.SetParent(pivot.transform); cameraGO.transform.localPosition=new Vector3(0,0,0);
        var cam = cameraGO.AddComponent<Camera>(); cam.fieldOfView=80; cam.nearClipPlane=.05f;
        cameraGO.AddComponent<AudioListener>();
        var playerScript=player.AddComponent<StrikePlayer>(); playerScript.cameraPivot=pivot.transform;

        // simple first-person weapon silhouette
        Cube("Weapon Body", cameraGO.transform.position + cameraGO.transform.forward*.65f + cameraGO.transform.right*.28f-cameraGO.transform.up*.23f, new Vector3(.18f,.16f,.55f), dark).transform.SetParent(cameraGO.transform, true);
        Cube("Weapon Barrel", cameraGO.transform.position + cameraGO.transform.forward*.95f + cameraGO.transform.right*.28f-cameraGO.transform.up*.20f, new Vector3(.055f,.055f,.35f), dark).transform.SetParent(cameraGO.transform, true);

        var manager = new GameObject("Strike Game Manager");
        var game=manager.AddComponent<StrikeGame>(); game.player=player.transform; game.cam=cam;
        manager.AddComponent<StrikeMobileUI>();

        Vector3[] spawns = { new Vector3(-10,1,12), new Vector3(10,1,12), new Vector3(-12,1,0), new Vector3(12,1,-8), new Vector3(0,1,17), new Vector3(7,1,-1) };
        for(int i=0;i<spawns.Length;i++) CreateBot(spawns[i], i%2==0?red:blue);

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/StrikeArena.unity");
        AssetDatabase.Refresh();
        EditorUtility.DisplayDialog("STRIKE MOBILE", "Сцена создана: Assets/Scenes/StrikeArena.unity\nНажми Play для запуска.", "OK");
    }

    static Material Mat(Color c) { var m=new Material(Shader.Find("Universal Render Pipeline/Lit")); if(m.shader==null)m.shader=Shader.Find("Standard"); m.color=c; return m; }
    static GameObject Cube(string name, Vector3 pos, Vector3 scale, Material mat) {
        var o=GameObject.CreatePrimitive(PrimitiveType.Cube); o.name=name; o.transform.position=pos; o.transform.localScale=scale; o.GetComponent<Renderer>().sharedMaterial=mat; return o;
    }
    static void CreateBot(Vector3 pos, Material mat) {
        var root=new GameObject("Enemy Bot"); root.transform.position=pos;
        var body=GameObject.CreatePrimitive(PrimitiveType.Capsule); body.name="Body"; body.transform.SetParent(root.transform); body.transform.localPosition=new Vector3(0,.05f,0); body.transform.localScale=new Vector3(.72f,.95f,.48f); body.GetComponent<Renderer>().sharedMaterial=mat;
        var head=GameObject.CreatePrimitive(PrimitiveType.Sphere); head.name="Head"; head.transform.SetParent(root.transform); head.transform.localPosition=new Vector3(0,1.05f,0); head.transform.localScale=Vector3.one*.42f; head.GetComponent<Renderer>().sharedMaterial=Mat(new Color(.68f,.52f,.39f));
        root.AddComponent<StrikeBot>();
    }
}
#endif
